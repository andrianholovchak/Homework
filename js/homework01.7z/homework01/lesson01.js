/*1.- Створити змінні. Присвоїти кожному з них значення: 'hello','owu','com', 'ua', 1, 10, -999, 123, 3.14, 2.7, 16, true, false.
  Вивести кожну змінну за допомогою: console.log , alert, document.write*/

/*let str= 'hello';
console.log(str);
document.write(str);
alert(str);*/

/*
let str='owu';
console.log(str);
document.write(str);
alert(str);*/

/*let str='com';
console.log(str);
document.write(str);
alert(str);*/

/*let str='ua';
console.log(str);
document.write(str);
alert(str);*/

/*
let one = 1;
console.log(one);
document.write(one);
alert(one);

let ten = 10;
console.log(ten);
document.write(ten);
alert(ten);

let negNumber = -199;
console.log(negNumber);
document.write(negNumber);
alert(negNumber);

let number = 123;
console.log(number);
document.write(number);
alert(number);

let numberOne = 3.14;
console.log(numberOne);
document.write(numberOne);
alert(numberOne);

let numberTwo = 2.7;
console.log(numberTwo);
document.write(numberTwo);
alert(numberTwo);

let sixTeen = 16;
console.log(sixTeen);
document.write(sixTeen);
alert(sixTeen);

let isTrue = true;
console.log(isTrue);
document.write(isTrue);
alert(isTrue);

let isFalse = false;
console.log(isFalse);
document.write(isFalse);
alert(isFalse);
*/




/*
2.- Переприсвоїти кожну змінну з завдання вище на будь які довільні значення.
  Вивести кожну змінну за допомогою: console.log , alert, document.write*/

/*
hello = 'owu';
console.log(hello);
document.write(hello);
alert(hello);

owu = 'hello';
console.log(owu);
document.write(owu);
alert(owu);

com = 'ua';
console.log(com);
document.write(com);
alert(com);

ua = 'com';
console.log(ua);
document.write(ua);
alert(ua);*/

/*one = 10;
console.log(one);
document.write(one);
alert(one);

ten = 1;
console.log(ten);
document.write(ten);
alert(ten);

negNumber = 123;
console.log(negNumber);
document.write(negNumber);
alert(negNumber);

number = -199;
console.log(number);
document.write(number);
alert(number);

numberOne = 2.7;
console.log(numberOne);
document.write(numberOne);
alert(numberOne);

numberTwo = 3.14;
console.log(numberTwo);
document.write(numberTwo);
alert(numberTwo);

sixTeen = true;
console.log(sixTeen);
document.write(sixTeen);
alert(sixTeen);

isTrue = 16;
console.log(isTrue);
document.write(isTrue);
alert(isTrue);

isFalse = true;
console.log(isFalse);
document.write(isFalse);
alert(isFalse);*/

/*
3.- Створити 3 змінних firstName, middleName, lastName, наповнити їх своїм ПІБ. Зконкатенувати їх в одну змінну person.*/

/*let firstName = 'Andrian';
let middleName = 'Igorovych';
let lastName = 'Holovchak';

let person = `${firstName} + ${middleName} + ${lastName}`;
console.log(person);*/

/*4.- За допомогою 3х різних prompt() отримати 3 слова які являються вашими Імям, По-Батькові та роками.
  Вивести "Вітаю *Імя* *По батькові*. Тобі *вік* років".*/

/*
const name = prompt('Name')
const age = prompt('Age')
const fathername = prompt('fathername')

console.log(`Вітаю ${name}, ${fathername} . Тобі ${age}`)
*/

/*5. За допомогою оператора typeof визначити типи наступних змінних та вивести їх в консоль.
  let a = 100; let b = '100'; let c = true;*/

/*let a = 100;
let b = '100';
let c = true;

console.log(
 typeof a,
 typeof b,
 typeof c,
);*/

/*
6.- Поставет відповідний оператор в виразах що б вийшов відповідний результат.
  В однакових виразаї не використовувати однакові оператори!!!
  5 < 6 -> true
5 > 6 -> false
5 === 6 -> false
5 <= 6 -> false
10 === 10 -> true
10 => 10 -> true
10 !== 10 -> false
10 < 10 -> false
10 > 10 -> false
123 === '123' -> false
123 ? '123' -> true*/

/*
7.Додатково:
  - Подивіться на наступні вирази і спробуйте вгадати яким буде вивід в консоль. Перевірте себе.*/
/*
console.log(132 > 100 && 45 < 12 ); false
console.log(34 > 33 && 23 < 90 ); true
console.log(99 > 100 && 45 > 12 ); false
console.log(132 > 100 || 45 < 12 ); true
console.log(111 > 11 || 45 < 111 ); true
console.log((111 > 11 || 45 < 111) && (132 > 100 || 45 < 12) ); true
console.log((111 > 11 || 45 < 56) || (132 > 100 || 45 < 12) ); true
console.log((132 > 100 && 45 < 12 ) && (132 > 100 || 45 < 12 ) ); false
console.log((111 > 11 || 45 < 111) || (99 > 100 && 45 > 12 )); true
console.log(!!'-1'); true
console.log(!!-1); false
console.log(!!'0'); true
console.log(!!'null'); true
console.log(!!'undefined');true
console.log(!!(3/'owu'));false
console.log((111 > 11 || 45 < 111) ||  !!'0');
console.log((!!111 == !!11 || 45 < 111) && (99 > 100 && 45 > 12 ));*!/*/
